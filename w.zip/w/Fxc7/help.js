// menu fitur bot
const help = (prefix, instagram, yt, name, pushname2, user, limitt, uptime, jam, tanggal) => { 
	return `

SUBSCRIBE:ANKER PRODUCTION
DI SITU ADA TUTORIAL JADI BOT

╭──────「 *REGULATION ${name}* 」
┴
┣⊱  \`\`\`NAMA USER:\`\`\` *${pushname2}*
┣⊱  \`\`\`VERIVICATION:\`\`\` ✅
┣⊱  \`\`\`LIMIT:\`\`\` *${limitt} perhari*
┣⊱  \`\`\`AKTIF:\`\`\` ${kyun(uptime)}
┣⊱  \`\`\`JAM:\`\`\` *${jam} WIB*
┣⊱  \`\`\`TANGGAL:\`\`\` *${tanggal}*
┣⊱  \`\`\`VERSION:\`\`\` *6.5.0*
┣⊱  \`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┣⊱  ❌ *SPAM*
┣⊱  ❌ *CALL & VC*
┣⊱  \`\`\`Melanggar??\`\`\` *Banned + Out Group*
┬
╰────────────────────────


╭──────「 *ABOUT ${name}* 」
┴
│➻ *${prefix}report lapor bug*
│➻ *${prefix}info*
│➻ *${prefix}donasi*
│➻ *${prefix}limit*
│➻ *${prefix}owner*
│➻ *${prefix}speed*
│➻ *${prefix}daftar*
│➻ *${prefix}totaluser*
│➻ *${prefix}blocklist*
│➻ *${prefix}banlist*
│➻ *${prefix}premiumlist*
│➻ *${prefix}bahasa*
┬
╰────────────────────────


͏͏͏͏͏͏͏͏͏͏͏͏͏͏╭──────「 *MEDIA DOWNLOADER* 」
┴
│➻ *${prefix}tiktokstalk username*
│➻ *${prefix}igstalk _farhan_xcode7*
│➻ *${prefix}instavid link valid*
│➻ *${prefix}instaimg link valid*
│➻ *${prefix}instastory username*
│➻ *${prefix}ssweb url*
│➻ *${prefix}url2img Url*
│➻ *${prefix}tiktok*
│➻ *${prefix}fototiktok*
│➻ *${prefix}memeindo*
│➻ *${prefix}kbbi*
│➻ *${prefix}wait*
│➻ *${prefix}trendtwit*
│➻ *${prefix}google berita terkini*
┬
╰────────────────────────


╭──────「 *CREATOR MENU* 」
┴
│➻ *${prefix}quotemaker tx/wtrmk/tema*
│➻ *${prefix}nulis nama/kelas/text*
│➻ *${prefix}croman FXC7 dan BOT*
│➻ *${prefix}slide Fxc7 BOT WA*
│
│➻ *${prefix}tahta FXC7*
│➻ *${prefix}cglass FXC7*
│➻ *${prefix}cstyle FXC7*
│➻ *${prefix}cgame FXC7*
│➻ *${prefix}clove FXC7*
│➻ *${prefix}cparty FXC7*
│➻ *${prefix}csky FXC7*
│➻ *${prefix}tts id Haii*
│➻ *${prefix}ttp Fxc7*
│➻ *${prefix}cballon Fxc7*
│➻ *${prefix}cpaper Fxc7*
│
│➻ *${prefix}stiker*
│➻ *${prefix}gifstiker*
│➻ *${prefix}toimg*
│➻ *${prefix}img2url*
│➻ *${prefix}tomp3*
│➻ *${prefix}ocr*
┬
╰──────────────────────────


╭───────「 *GROUP ONLY* 」
┴
│➻ *${prefix}modeanime On/Off*
│➻ *${prefix}naruto*
│➻ *${prefix}minato*
│➻ *${prefix}boruto*
│➻ *${prefix}hinata*
│➻ *${prefix}sakura*
│➻ *${prefix}sasuke*
│➻ *${prefix}toukachan*
│➻ *${prefix}rize*
│➻ *${prefix}akira*
│➻ *${prefix}itori*
│➻ *${prefix}kurumi*
│➻ *${prefix}miku*
│➻ *${prefix}anime*
│➻ *${prefix}animecry*
│➻ *${prefix}neonime*
│➻ *${prefix}animekiss*
┬
╰───────────────────────

╭───────「 *GROUP ONLY* 」
┴
│➻ *${prefix}welcome On/Off*
│➻ *${prefix}grup buka/tutup*
│➻ *${prefix}ownergrup*
│➻ *${prefix}setpp*
│➻ *${prefix}infogc*
│➻ *${prefix}add 628xxxxxxxxxx*
│➻ *${prefix}kick @mentioned*
│➻ *${prefix}kicktime @mentioned*
│➻ *${prefix}promote @mentioned*
│➻ *${prefix}demote @mentioned*
│➻ *${prefix}setname*
│➻ *${prefix}setdesc*
│➻ *${prefix}linkgrup*
│➻ *${prefix}tagme*
│➻ *${prefix}hidetag*
│➻ *${prefix}tagall*
│➻ *${prefix}mentionall*
│➻ *${prefix}fitnah*
│➻ *${prefix}listadmin*
┬
╰────────────────────────

╭───────「 *GROUP ONLY* 」
┴
│➻ *${prefix}nsfw On/Off*
│➻ *${prefix}nsfwloli*
│➻ *${prefix}nsfwblowjob*
│➻ *${prefix}nsfwneko*
│➻ *${prefix}nsfwtrap*
│➻ *${prefix}hentai*
│➻ *${prefix}simih On/Off*
┬
╰────────────────────────


╭──────「 *OTHERS FUN & GAME* 」
┴
│➻ *${prefix}anjing*
│➻ *${prefix}kucing*
│➻ *${prefix}testime*
│➻ *${prefix}hilih*
│➻ *${prefix}apakah*
│➻ *${prefix}kapankah*
│➻ *${prefix}bisakah*
│➻ *${prefix}rate*
│➻ *${prefix}watak*
│➻ *${prefix}hobby*
│➻ *${prefix}infogempa*
│➻ *${prefix}infonomor*
│➻ *${prefix}quotes*
│➻ *${prefix}truth*
│➻ *${prefix}dare*
│➻ *${prefix}katabijak*
│➻ *${prefix}fakta*
│➻ *${prefix}darkjokes*
│➻ *${prefix}bucin*
│➻ *${prefix}pantun*
│➻ *${prefix}katacinta*
│➻ *${prefix}jadwaltvnow*
│➻ *${prefix}hekerbucin*
│➻ *${prefix}katailham*
┬
╰────────────────────────

╭──────「 *OTHERS FUN & GAME* 」
┴
│➻ *${prefix}jarak Banyuwangi/Surabaya*
│➻ *${prefix}translate en/Apa kabar?*
│➻ *${prefix}pasangan Farhan/Iriene*
│➻ *${prefix}gantengcek Farhan*
│➻ *${prefix}cantikcek Iriene*
│➻ *${prefix}artinama Farhan*
│➻ *${prefix}persengay Topan*
│➻ *${prefix}pbucin Farhan*
│➻ *${prefix}bpfont Farhan*
│➻ *${prefix}textstyle FXC7*
│➻ *${prefix}jadwaltv antv*
│➻ *${prefix}lirik melukis senja*
│➻ *${prefix}chord Melukis senja*
│➻ *${prefix}wiki Adolf Hitler*
│➻ *${prefix}brainly pertanyaan*
│➻ *${prefix}resepmasakan rawon*
│➻ *${prefix}map Banyuwangi*
│➻ *${prefix}film Fast and Farious*
│➻ *${prefix}pinterest gambar kucing*
│➻ *${prefix}infocuaca Banyuwangi*
│➻ *${prefix}jamdunia Banyuwangi*
│➻ *${prefix}mimpi Ular*
│➻ *${prefix}infoalamat jalan Banyuwangi*
│➻ *${prefix}playstore WhatsApp*
┬
╰───────────────────────────


╭──────「 *OTHERS FUN & GAME* 」
┴
│➻ *${prefix}puisiimg*
│➻ *${prefix}asupan*
│➻ *${prefix}tebakgambar*
│➻ *${prefix}caklontong*
│➻ *${prefix}family100*
│➻ *${prefix}kalkulator 13*12*
│➻ *${prefix}moddroid lightroom*
│➻ *${prefix}happymod lightroom*
┬
╰────────────────────────

╭──────「 *OTHERS FUN & GAME* 」
┴
│➻ *${prefix}cerpen*
│➻ *${prefix}cersex*
│➻ *${prefix}randombokep*
│➻ *${prefix}pornhub stepMoms*
│➻ *${prefix}xvideos japan*
│➻ *${prefix}nekopoi oni chichi*
┬
╰────────────────────────

╭──────「 *OTHERS FUN & GAME* 」
┴
│➻ *${prefix}jadwalsholat Banyuwangi*
│➻ *${prefix}quran*
│➻ *${prefix}quranlist*
│➻ *${prefix}quransurah 1*
┬
╰────────────────────────

╭──────「 *OTHERS FUN & GAME* 」
┴
│➻ *${prefix}becrypt string*
│➻ *${prefix}encode64 string*
│➻ *${prefix}decode64 encrypt*
│➻ *${prefix}encode32 string*
│➻ *${prefix}decode32 encrypt*
│➻ *${prefix}encbinary string*
│➻ *${prefix}decbinary encrypt*
│➻ *${prefix}encoctal string*
│➻ *${prefix}decoctal encrypt*
│➻ *${prefix}hashidentifier Encrypt Hash*
│➻ *${prefix}dorking dork*
│➻ *${prefix}pastebin teks*
│➻ *${prefix}tinyurl link*
│➻ *${prefix}bitly link*
┬
╰────────────────────────

╭──────「 *OTHERS FUN & GAME* 」
┴
│➻ *${prefix}spamcall 083xxxxxxxxx*
│➻ *${prefix}spamsms 083xxxxxxxx/jumlah*
│➻ *${prefix}spamgmail contoh@gmail.com*
┬
╰────────────────────────


╭─────────「 *OWNER ONLY* 」
┴
│➻ *${prefix}addprem mentioned*
│➻ *${prefix}removeprem mention*
│➻ *${prefix}setmemlimit*
│➻ *${prefix}setreply*
│➻ *${prefix}setprefix*
│➻ *${prefix}setnamebot*
│➻ *${prefix}setppbot*
│➻ *${prefix}bc*
│➻ *${prefix}bcgc*
│➻ *${prefix}ban*
│➻ *${prefix}unban*
│➻ *${prefix}block*
│➻ *${prefix}unblock*
│➻ *${prefix}clearall*
│➻ *${prefix}delete*
│➻ *${prefix}clone*
│➻ *${prefix}getses*
│➻ *${prefix}leave*
┬
╰────────────────────────


╭────────「 *PREMIUM ONLY* 」
┴
│➻ *${prefix}playmp3 menepi*
│➻ *${prefix}fb link video*
│➻ *${prefix}snack link snack video*
│➻ *${prefix}ytmp3 link yt*
│➻ *${prefix}ytmp4 link yt*
│➻ *${prefix}joox Monolog Pamungkas*
│➻ *${prefix}smule Link Video Smule*
┬
╰────────────────────────


╭─────「 *SUPPORT ${name}* 」
┴
│➲ *O BOT*
│➲ *M. HADI FIRMANSYA*
│➲ *DELIA AULIA*
│➲ *KEVIN DAVID*
│➲ *MY TEAM FXC7 BOT*
│➲ *CONTENT CREATOR BOT WHATSAPP*
│➲ *FXC7*
┬
╰────────────────────────`
}

exports.help = help

// penghitung aktif bot
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `*${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik*`
}

// donasi menu
const donasi = (name) => { 
	return `       
╭─────「 *DONASI SEIKHLASNYA* 」
┴
│√ *PULSA: 08311800241*
│√ *OVO : 08311800241*
┬
╰──────「 *BY ${name}* 」

Untuk Kelangsungan Hidup Bot Karna Kuota Mahal:'
`
}
exports.donasi = donasi

// bahasa list
const bahasa = (prefix) => {
return `
List Bahasa Untuk Command *${prefix}tts*

  af: Afrikaans
  sq: Albanian
  ar: Arabic
  hy: Armenian
  ca: Catalan
  zh: Chinese
  zh-cn: Chinese (Mandarin/China)
  zh-tw: Chinese (Mandarin/Taiwan)
  zh-yue: Chinese (Cantonese)
  hr: Croatian
  cs: Czech
  da: Danish
  nl: Dutch
  en: English
  en-au: English (Australia)
  en-uk: English (United Kingdom)
  en-us: English (United States)
  eo: Esperanto
  fi: Finnish
  fr: French
  de: German
  el: Greek
  ht: Haitian Creole
  hi: Hindi
  hu: Hungarian
  is: Icelandic
  id: Indonesian
  it: Italian
  ja: Japanese
  ko: Korean
  la: Latin
  lv: Latvian
  mk: Macedonian
  no: Norwegian
  pl: Polish
  pt: Portuguese
  pt-br: Portuguese (Brazil)
  ro: Romanian
  ru: Russian
  sr: Serbian
  sk: Slovak
  es: Spanish
  es-es: Spanish (Spain)
  es-us: Spanish (United States)
  sw: Swahili
  sv: Swedish
  ta: Tamil
  th: Thai
  tr: Turkish
  vi: Vietnamese
  cy: Welsh
`
}
exports.bahasa = bahasa

// Limit
const limitend = (pushname2) => {
        return`*maaf ${pushname2} limit hari ini habis*\n*limit di reset setiap jam 12:00 WIB TENGAH MALAM*`
}

const limitcount = (limitCounts) => {
        return`
Limit Kamu: ${limitCounts}
`
}

exports.limitend = limitend
exports.limitcount = limitcount
