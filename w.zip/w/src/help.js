const help = (prefix) => {
	return `
𝗢𝗹𝗮́, 𝗯𝗲𝗺 𝘃𝗶𝗻𝗱𝗼(𝗮) 𝗮𝗼 𝗺𝗲𝘂𝗻𝘂 𝗱𝗼 𝗯𝗼𝘁
 *𝗦𝗢𝗕𝗥𝗘 𝗢 𝗕𝗢𝗧:*
➤ *𝗗𝗢𝗡𝗢: 𝗡𝗔𝗕𝗨𝗧𝗢*
➤ *𝗖𝗥𝗜𝗔𝗗𝗢: 13 𝗙𝗘𝗩
➤ *𝗪𝗣𝗣: wa.me/556993733829*
➤ 𝗬𝗢𝗨𝗧𝗨𝗕𝗘: https://youtube.com/channel/UCZEtf9AlsC2zsJQwrfW-44w
┴
 ➣NOME DE USUÁRIO: *${pushname2}*
 ➣VERIFICAÇÃO: ✅
 ➣ ON:  ${kyun(uptime)}
 ➣ATIVO: *${jam} WIB*
 ➣ *${tanggal}*
 ➣:VIPZADA
Loading…
█▒▒▒▒▒▒▒▒▒
10%
███▒▒▒▒▒▒▒
30%
█████▒▒▒▒▒
50%
███████▒▒▒
100%
██████████

      𝗖𝗢𝗠𝗔𝗡𝗗𝗢𝗦:
➢【 𝗡𝗢𝗩𝗜𝗗𝗔𝗗𝗘𝗦 】
☛
☛1 *${prefix}animecry*
☛2 *${prefix}chentai [premium]*
☛3 *${prefix}gcpf [premium]*
☛4 *${prefix}gay [@]*
☛5 *${prefix}gbin [premium]*
☛5 *${prefix}pack [premium]*
☛6 *${prefix}destrava [premium]*
☛7 *${prefix}gpessoa [premium]*
☛8 *${prefix}wame*
☛9 *${prefix}spamcall*
☛10 *${prefix}play (nome da msc)*
☛



➢𝗙𝗨𝗡𝗖̧𝗢̃𝗘𝗦 𝗩𝗜𝗣 𝗔𝗧𝗨𝗔𝗟𝗜𝗭𝗔𝗗𝗢 𝗗𝗘 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 🔍✴️✴️

☛*${prefix}cpf

☛*${prefix}cnpj

☛*${prefix}ip

☛*${prefix}cep

☛*${prefix}placa






➢【 𝗠𝗘𝗡𝗨 】
☛
☛11 *${prefix}figu*
☛12 *${prefix}toimg*
☛13 *${prefix}nabutojokes (memes aleatórios)*
☛14 *${prefix}memeindo*
☛15 *${prefix}tts*
☛16 *${prefix}lolih [on]*
☛17 *${prefix}nsfwloli [off]*
☛18 *${prefix}url2img*
☛19 *${prefix}leens [na legenda]*
☛20 *${prefix}wait [na legenda]*
☛21 *${prefix}setprefix*
☛
➢【 𝗢𝗨𝗧𝗥𝗢𝗦 】
☛
☛22 *${prefix}linkgp*
☛23 *${prefix}simih [1/0]*
☛24 *${prefix}marcar*
☛25 *${prefix}add [@]*
☛26 *${prefix}banir [@]*
☛27 *${prefix}promover [@]*
☛28 *${prefix}rebaixar*
☛29 *${prefix}admins*
☛30 *${prefix}marcar2*
☛31 *${prefix}bc [texto]* (ele faz uma ™)
☛32 *${prefix}marcar3*
☛33 *${prefix}bloqueados*
☛34 *${prefix}bloquear [@]*
☛35 *${prefix}desbloquear [@]*
☛36 *${prefix}limpar*
☛37 *${prefix}bc [ *texto* ]*
☛38 *${prefix}bemvindo [1/0]*
☛39 *${prefix}clonar [@]*
☛40 *${prefix}help1*
☛41 *${prefix}dono*
☛42 *${prefix}owner*
☛43 *${prefix}tts [texto]*
☛44 *${prefix}setnome*
☛45 *${prefix}termux*
☛46 *${prefix}setfoto*
☛47 *${prefix}grupoinfo*
☛48 *${prefix}ytmp4*
☛49 *${prefix}bomdia*
☛50 *${prefix}boanoite*
☛51 *${prefix}marcar*
☛52 *${prefix}marcar2*
☛53 *${prefix}marcar3*
☛
➢【 𝗜𝗠𝗔𝗚𝗘𝗡𝗦 】
☛
☛54 *${prefix}loli* [off]
☛55 *${prefix}loli1*
☛56 *${prefix}hentai*
☛57 *${prefix}dono*
☛58 *${prefix}porno*
☛59 *${prefix}boanoite*
☛60 *${prefix}bomdia*
☛61 *${prefix}boatarde*
☛62 *${prefix}mia [aleatórias]*
☛63 *${prefix}rize [aleatórias]*
☛64 *${prefix}minato [aleatórias]*
☛65 *${prefix}boruto [aleatórias]*
☛66 *${prefix}hinata [aleatórias]*
☛67 *${prefix}sasuke [aleatórias]*
☛68 *${prefix}sakura [aleatórias]*
☛69 *${prefix}naruto [aleatórias]*
☛70 *${prefix}meme*   
☛71 *${prefix}lofi*
☛72 *${prefix}malkova*
☛73 *${prefix}canal*
☛74 *${prefix}nsfwloli1*
☛75 *${prefix}reislin*
☛
➢【 𝗜𝗡𝗧𝗘𝗟𝗜𝗚𝗘̂𝗡𝗖𝗜𝗔 𝗜𝗔 】
☛
☛76 *${prefix}simih 1 (para ativar)*
☛77 *${prefix}simih 0 (para desativar)*
☛ *${prefix}simi (sua mensagem)*
☛
➢【 𝗘𝗠 𝗧𝗘𝗦𝗧𝗘 】
☛
☛78 *${prefix}*
☛79 *${prefix}*
☛80 *${prefix}*
☛
➢【 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 】
☛
☛81 *${prefix}dado*
☛82 *${prefix}cekvip*
☛83 *${prefix}premiumlist*
☛84 *${prefix}delete*
☛85 *${prefix}modapk*
☛86 *${prefix}indo10*
☛87 *${prefix}daftarvip [para virar Premium]*
☛88 *${prefix}qrcode*
☛89 *${prefix}chentai*
☛90 *${prefix}gcpf*
☛91 *${prefix}gbin*
☛92 *${prefix}pack*
☛93 *${prefix}destrava*
☛94 *${prefix}gpessoa*
☛
➢【 𝗚𝗥𝗨𝗣𝗢 】
☛
☛95 *${prefix}banir*
☛96 *${prefix}leveling [on/off]*
☛97 *${prefix}level*
☛98 *${prefix}add*
☛99 *${prefix}promover*
☛100 *${prefix}setfoto [na legenda]*
☛101 *${prefix}setname [texto]*
☛102 *${prefix}rebaixar*
☛103 *${prefix}admins*
☛104 *${prefix}marcar*
☛105 *${prefix}marcar2*
☛106 *${prefix}marcar3*
☛107 *${prefix}bemvindo [1/0]*
☛108 *${prefix}grupoinfo*
☛109 *${prefix}bomdia*
☛110 *${prefix}boatarde*
☛111 *${prefix}boanoite*
☛112 *${prefix}setdesc*
☛113 *${prefix}bug [sua mensagem]*
☛
➢【 𝗘𝗦𝗣𝗘𝗖𝗜𝗙𝗜𝗖𝗢 𝗗𝗢 𝗕𝗢𝗧 】𝗹
☛
☛114 *${prefix}bug [sua mensagem]*
☛115 *${prefix}clonar [@]*
☛116 *${prefix}dono*
☛117 *${prefix}ping [ver velocidade do bot]*
☛118 *${prefix}termux*
☛119 *${prefix}gay [@]*
☛120 *${prefix}wame*
☛121 *${prefix}map (nome)*
☛122 *${prefix}setppbot (marque uma img)*
☛123 *${prefix}pinterest (nome)*
☛124 *${prefix}desligar (so para o dono)*
☛125 *${prefix}timer*
☛
➢【 𝗠𝗔𝗜𝗦 𝗔𝗟𝗚𝗨𝗡𝗦 】𝗹
☛
☛126 *${prefix}neko*
☛127 *${prefix}ttp [texto]*
☛128 *${prefix}testime*
☛129 *${prefix}tomp3*
☛130 *${prefix}modoanime [on/off]*
☛131 *${prefix}modonsfw [on/off]*
☛132 *${prefix}happymod [jogo/app]*
☛133 *${prefix}rize*
☛134 *${prefix}ytsearch*
☛135 *${prefix}moddroid [jogo/app]*
☛136 *${prefix}xvideos [titulo]**
☛137 *${prefix}nomegp*
☛138 *${prefix}nabutojokes (memes aleatórios)*
☛139 *${prefix}animecry*
☛140 *${prefix}gay1*
☛141 *${prefix}next*
☛142 *${prefix}alerta*
☛143 *${prefix}belle [img aleatórias]*
☛144 *${prefix}pronomeneu [texto]*
☛144 *${prefix}hobby*
☛
➢【 𝗖𝗢𝗠𝗔𝗡𝗗𝗢𝗦 𝗗𝗘 𝗩𝗢𝗭 】
☛
☛145 *${prefix}oiamor*
☛146 *${prefix}baka*
☛147 *${prefix}lilpep1*
☛148 *${prefix}lilpep2*
☛149 *${prefix}oni-chan*
☛150 *${prefix}rude*
☛151 *${prefix}melhorabertura*
☛152 *${prefix}xxxtentacion1*
☛153 *${prefix}xxxtentacion2*
☛
➢【 𝗢𝗨𝗧𝗥𝗢𝗦 /2 】
☛
☛154 *${prefix}antilink [1/0]*
☛155 *${prefix}brainly [pergunta]*
☛156 *${prefix}antiracismo [on/off]*
☛157 *${prefix}setnomebot*
☛158 *${prefix}meme*
☛
➢【 𝗜𝗡𝗧𝗘𝗥𝗔𝗧𝗜𝗩𝗢𝗦 】
☛
NOTA »
☛Mandar a msg sem o prefixo
➤➤➤➤➤
☛
☛159 *yamete*
☛160 *mscpararelaxar*
☛161 *mscparaalegrar*
☛162 *darling*
☛
☛
➢【 𝗗𝗢𝗡𝗢 】
☛
☛ *𝗡𝗢𝗠𝗘: nabuto
☛ *𝗪𝗣𝗣: wa.me/+556993733829
☛
☛
☛
☛
【 NABUTO 】`
}

exports.help = help




